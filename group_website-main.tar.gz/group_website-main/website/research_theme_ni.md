# Ongoing projects

> Development of Advanced Virgo mode-matching telescopes


````{grid}
:gutter: 2

```{grid-item-card} [Tacca_2016]
Tuning of a high magnification compact parabolic
telescope for centimeter-scale laser beams
```

```{grid-item-card} [Buy_2017]
Design of a high-magnification
and low-aberration compact catadioptric
telescope for the Advanced Virgo
gravitational-wave interferometric detector
```
````

> Commissioning of Virgo frequency-dependent squeezing source

````{grid}
:gutter: 2

```{grid-item-card} [Acernese_2023]
Frequency-Dependent Squeezed Vacuum Source for the Advanced Virgo Gravitational-Wave Detector
```

```{grid-item-card} [Bonavena_2023]
Thermal detuning of a bichromatic narrow linewidth optical cavity
```
````

> Quantum-FRESCO: Frequecy dependent squeezing for next generation GW detectors 

> Virgo optical characterization

> Lunar GW detector

[Buy_2017]: https://iopscience.iop.org/article/10.1088/1361-6382/aa65e3/meta
[Tacca_2016]: https://opg.optica.org/ao/fulltext.cfm?uri=ao-55-6-1275&id=336264
[Acernese_2023]: https://journals.aps.org/prl/abstract/10.1103/PhysRevLett.131.041403
