# Past projects

> Full scale Frequency-dependent squeezing source protoype for quantum noise reduction in GW detectors

````{grid}
:gutter: 3

```{grid-item-card} [Capocasa_2016]
Estimation of losses in a 300 m filter cavity and quantum noise reduction in the KAGRA gravitational-wave detector
```

```{grid-item-card} [Capocasa_2018]
Measurement of optical losses in a high-finesse 300 m filter cavity for broadband quantum noise reduction in gravitational-wave detectors
```

```{grid-item-card} [Zhao_2020]
Frequency-Dependent Squeezed Vacuum Source for Broadband Quantum Noise Reduction in Advanced Gravitational-Wave Detectors
```

```{grid-item-card} [Zhao_2022]
Improving the stability of frequency-dependent squeezing with bichromatic control of filter cavity length, alignment, and incident beam pointing
```

```{grid-item-card} [Aritomi_2022]
Demonstration of length control for a filter cavity with coherent control sidebands
```

````


> Higher-order Laguerre-Gauss modes for thermal noise reduction in GW detectors  

````{grid}
:gutter: 3

```{grid-item-card} [Granata_2010]
Higher-order Laguerre-Gauss mode generation and interferometry for gravitational wave detectors
```

```{grid-item-card} [Gatto_2014]
Fabry-Pérot-Michelson interferometer using higher-order Laguerre-Gauss modes
```

```{grid-item-card} [Allocca_2015]
Higher-order Laguerre-Gauss interferometry for gravitational-wave detectors with in situ mirror defects compensation
```

````

> Frequency dependent squeezing realization via EPR entanglement

````{grid}
:gutter: 1

```{grid-item-card} [Nguyen_2022]
Thermally-controlled optical resonator for vacuum squeezed states separation
```

````

> Infrasound atmospheric noise studies for next generation GW detectors 

````{grid}
:gutter: 1

```{grid-item-card} [Fiorucci_2018]
Impact of infrasound atmospheric noise on gravity detectors used for astrophysical and geophysical applications
```

````


[Buy_2017]: https://iopscience.iop.org/article/10.1088/1361-6382/aa65e3/meta
[Tacca_2016]: https://opg.optica.org/ao/fulltext.cfm?uri=ao-55-6-1275&id=336264
[Capocasa_2016]: https://journals.aps.org/prd/abstract/10.1103/PhysRevD.93.082004
[Capocasa_2018]: https://journals.aps.org/prd/abstract/10.1103/PhysRevD.98.022010
[Zhao_2020]: https://journals.aps.org/prl/abstract/10.1103/PhysRevLett.124.171101
[Granata_2010]: https://journals.aps.org/prl/abstract/10.1103/PhysRevLett.105.231102
[Gatto_2014]: https://journals.aps.org/prd/abstract/10.1103/PhysRevD.90.122011
[Allocca_2015]: https://journals.aps.org/prd/abstract/10.1103/PhysRevD.92.102002
[Nguyen_2022]: https://opg.optica.org/ao/abstract.cfm?uri=ao-61-17-5226
[Fiorucci_2018]: https://journals.aps.org/prd/abstract/10.1103/PhysRevD.97.062003
[Zhao_2022]: https://journals.aps.org/prd/abstract/10.1103/PhysRevD.105.082003
[Aritomi_2022]: https://journals.aps.org/prd/abstract/10.1103/PhysRevD.106.102003

