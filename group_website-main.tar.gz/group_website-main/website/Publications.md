# Publications

## 2023

- A. Cahuzac, M. Gross, E. Capocasa, M. Barsuglia, R. Flaminio, P. La Penna "Frequency-dependent reflection of a misaligned beam by a Fabry–Pérot cavity" [Appl. Phys. Lett. 123, 044101 (2023)](https://doi.org/10.1063/5.0148462).

- F. Acernese, et al. "Frequency-Dependent Squeezed Vacuum Source for the Advanced Virgo Gravitational-Wave Detector" [Phys. Rev. Lett. 131, 041403](https://journals.aps.org/prl/abstract/10.1103/PhysRevLett.131.041403)

## 2022

- C. Nguyen, E. Bréelle, M. Barsuglia, E. Capocasa, M. De Laurentis, V. Sequino, and F. Sorrentino "Thermally controlled optical resonator for vacuum squeezed states separation." [Appl. Opt. 61, 5226-5236 (2022)](https://doi.org/10.1364/AO.459190)

- Y.Zhao, E. Capocasa, M. Eisenmann et al. "Improving the stability of frequency-dependent squeezing with bichromatic control of filter cavity length, alignment, and incident beam pointing" [Phys. Rev. D 105, 082003](https://journals.aps.org/prd/abstract/10.1103/PhysRevD.105.082003)

- N. Aritomi, Y. Zhao, E. Capocasa et al. "Demonstration of length control for a filter cavity with coherent control sidebands" [Phys. Rev. D 106, 102003 (2022)](https://doi.org/10.1103/PhysRevD.106.102003)

## 2020

- Y. Zhao, N. Aritomi, E. Capocasa et al. "Frequency-dependent squeezed vacuum source for broadband quantum noise reduction in advanced gravitational-wave detectors" [Phys. Rev. Lett. 124, 171101](https://doi.org/10.1103/PhysRevLett.124.171101)


## 2018

- E. Capocasa, Y. Guo, M. Eisenmann, Y. Zhao et al. "Measurement of optical losses in a high-finesse 300 m filter cavity for broadband quantum noise reduction in gravitational-wave detectors" [Phys. Rev. D 98, 022010](https://doi.org/10.1103/PhysRevD.98.022010)

- D. Fiorucci, J. Harms, M. Barsuglia, I. Fiori, F. Paoletti "Impact of infrasound atmospheric noise on gravity detectors used for astrophysical and geophysical applications" [Phys. Rev. D 97, 062003](https://doi.org/10.1103/PhysRevD.97.062003)

## 2017

- C. Buy, E. Genin, M. Barsuglia, R. Gouaty, M. Tacca, "Design of a high-magnification and low-aberration compact catadioptric telescope for the Advanced Virgo gravitational-wave interferometric detector" [Class. Quantum Grav. 34 095011](https://iopscience.iop.org/article/10.1088/1361-6382/aa65e3)

## 2016

- E.Capocasa, M. Barsuglia, J. Degallaix, et al. "Estimation of losses in a 300 m filter cavity and quantum noise reduction in the KAGRA gravitational-wave detector" [Phys. Rev. D 105, 082003](https://doi.org/10.1103/PhysRevD.93.082004)

- M. Tacca, F. Sorrentino, C. Buy, M. Laporte, G. Pillant, E. Genin, P. La Penna, M. Barsuglia. "Tuning of a high magnification compact parabolic telescope for centimeter-scale laser beams" [Appl. Opt. 55, 1275-1283 (2016)](https://doi.org/10.1364/AO.55.001275)

## 2015

- A. Allocca, A. Gatto, M. Tacca, R. A. Day, M. Barsuglia, G. Pillant, C. Buy, and G. Vajente "Higher-order Laguerre-Gauss interferometry for gravitational-wave detectors with in situ mirror defects compensation" [Phys. Rev. D 92, 102002](https://doi.org/10.1103/PhysRevD.92.102002)

## 2014

- A. Gatto, M. Tacca, F. Kéfélian, C. Buy, and M. Barsuglia "Fabry-Pérot-Michelson interferometer using higher-order Laguerre-Gauss modes" [Phys. Rev. D 90, 122011](https://doi.org/10.1103/PhysRevD.90.122011)

## 2010

- M. Granata, C. Buy, R. Ward, and M. Barsuglia "Higher-order Laguerre-Gauss mode generation and interferometry for gravitational wave detectors" [Phys. Rev. Lett. 105, 231102](https://doi.org/10.1103/PhysRevLett.105.231102)
