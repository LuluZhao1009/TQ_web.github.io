## Our visitors

### 2024

### 2023

| Date | Visitor | Seminar topic |
| :---         |:---      | :---         |
| 11 Sep | Yohei Nishino  |  Frequency-dependent squeezing for gravitational-wave detection through quantum teleportation  |
| 12 Oct | Zonghong Zhu  |  An overview of the prototype gravitational wave detector in BNU, Introduction to detecting gravitational waves on the Moon  |
| 27 Oct | Tiancai Zhang, YaoHui Zheng, Wei Li, Pengfei Zhang |   Quantum optics experiments in Shanxi University   |
| 17 Nov | Pengbo Li |  Construction and development of position sensors for seismic attenuators of the ETpathfinder experiment  |
