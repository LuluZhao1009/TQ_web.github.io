# Permanent members


## Matteo Barsuglia

<div style="display: flex; align-items: center;">
    <img src="_static/matteo.png" alt="Your Image" style="width: 40%; margin-right: 20px;">
    <p>
    <ul>
            <li>Position: Directeur de recherche</li>
            <li>Bio: Matteo has been working for 25 years on the development of the Virgo interferometer. The first part of his career was dedicated to the realization and operation of the first-generation Virgo detector. In 2008,he co-founded a new Virgo group at the Laboratoire APC and contributed to the design and development of Advanced Virgo detector as head of the optics design group. He has been developing techniques to improve the sensitivity of GW detectors through the use of non-gaussian laser modes, reduction of gravity gradient noises and more recently with research about quantum squeezing. He also developed an interdisciplinary activity about the use of gravity signals from earthquakes to improve the early-warning earthquake systems. Since July 2018, he has been director of the PCCP (Paris Center for Cosmological Physics), a structure of the APC laboratory focused on education, outreach and the impact of science on the arts and society.</li>
    </ul>
    </p>
</div>


## Eleonora Capocasa

<div style="display: flex; align-items: center;">
    <img src="_static/eleonora.png" alt="Your Image" style="width: 40%; margin-right: 20px;">
    <p>
    <ul>
            <li>Position: Maîtresse de conference </li>
            <li>Bio: Eleonora is a researcher with expertise in optics. </li>
    </ul>
    </p>
</div>



## Anne Daumas

<div style="display: flex; align-items: center;">
    <img src="_static/anne.png" alt="Your Image" style="width: 40%; margin-right: 20px;">
    <p>
    <ul>
            <li>Position: Research engineer</li>
            <li>Bio: Anne Daumas is a research engineer at CNRS specializing in optical engineering. After graduating from Institut d'Optique (Paris-Saclay) with expertise in theoretical and applied optics, she contributes to ground-based and spaced-based gravitationnal wave detectors Virgo and LISA, focusing on instrumentation, prototyping and optical simulations. She also has previous experience as an apprentice at HORIBA France working on an optical instrument for semi-conductor research, and she started at CNRS on a short-term contract before getting a permanent position in 2023.</li>
    </ul>
    </p>
</div>




## Pierre Prat

<div style="display: flex; align-items: center;">
    <img src="_static/pierre.png" alt="Your Image" style="width: 40%; margin-right: 20px;">
    <p>
    <ul>
            <li>Position: Research engineer</li>
            <li>Bio: Pierre Prat received a Diploma in Electrical Engineering from the INSA (National Institute of Applied Sciences) of Rennes, France in 1986. In 2004, he joined APC where he is working as a research engineer in Electronics. His current research interests are in the fields of low noise electronic system design for space-based detectors, especially the LISA project. He is also contributing to the Virgo GW detector, developing photodetectors for the interferometer control and electronic component for R&D activity on quantum noise reduction for GW detectors.</li>
    </ul>
    </p>
</div>



