# PhD thesis

**2011** - Massimo Granata, *"Optical development for second- and third-generation gravitational-wavedetectors: stable recycling cavities for advanced virgo and higher-order Laguerre-Gauss modes"* [link](https://theses.hal.science/tel-00665858/document)



**2017** - Eleonora Capocasa, *"Optical and noise studies for Advanced Virgo and filter cavities for quantum noise reduction in gravitational-wave interferometric detectors"* [link](https://theses.hal.science/tel-03141038/file/capocasa_thesis_2017.pdf)



**2021** - Catherine Nguyen, *"Development of squeezing techniques for quantum noise reduction in gravitational-wave detectors"* [link](https://theses.hal.science/tel-03783690v1/document)
