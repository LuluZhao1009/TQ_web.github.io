# Virgo/ET experimental team at APC 

Our team is part of the gravitation group of [APC laboratory](https://apc.u-paris.fr/APC_CS/en), in Paris. We carry out research activities aiming to the development of ground based gravitational-wave detectors. In particular we work on Virgo and Einsten Telescope projects.


## Virgo

The [Virgo](https://www.virgo-gw.eu/) collaboration works as a community on the building, development and operation of the Virgo gravitational-wave detector, hosted by the European Gravitational Observatory ([EGO](https://www.ego-gw.it/)) at Cascina, near Pisa, Italy. 

## ET

The Einstein Telescope ([ET](https://www.et-gw.eu/)) is a proposed underground infrastructure to host a third-generation, gravitational-wave observatory. It builds on the success of current, second-generation laser-interferometric detectors Advanced Virgo and Advanced LIGO, whose breakthrough discoveries of merging black holes (BHs) and neutron stars over the past  years have ushered scientists into the new era of gravitational-wave astronomy.  The Einstein Telescope will achieve a greatly improved sensitivity by increasing the size of the interferometer from the 3km arm length of the Virgo detector to 10km, and by implementing a series of new technologies. These include a cryogenic system to cool some of the main optics to 10 – 20K, new quantum technologies to reduce the fluctuations of the light, and a set of infrastructural and active noise-mitigation measures to reduce environmental perturbations.


```{tableofcontents}
```


