# Presentations


## 2024

| Date | Title | Speaker | Event |Link |
| :---         |:---         | :---  | :---      | :---|
| 15 Jan | Sonification of Squeezed Vacuum State of Light: Unveiling Quantum Dynamics through Sound   | Yuhang Zhao   |[1st CREDO workshop](https://indico.ifj.edu.pl/event/1176/overview) | https://indico.ifj.edu.pl/event/1176/overview  [CREDO_sqz_soni.pdf](uploads/c992ee826d9deb8cc1e959413cb928f4/CREDO_sqz_soni.pdf)   |
| 16 Apr | Status of Virgo   | Yuhang Zhao   |[11st Kagra International Workshop](https://indico.phys.sinica.edu.tw/event/92/) |  https://indico.phys.sinica.edu.tw/event/92/contributions/651/  |
| 13 May | Gravitational-wave astronomy with ground-based interferometric detectors: from birth to the future   | Eleonora Capocasa   |[LPNHE seminar](https://indico.in2p3.fr/event/32906/) |   https://indico.in2p3.fr/event/32906/  |

## 2023

| Date | Title | Speaker | Event |Link |
| :---         |:---         | :---  | :---      | :---|
| 24 Jan | QNR Status and Plan   | Yuhang Zhao   |[Virgo Week](https://indico.ego-gw.it/event/537/) | https://tds.virgo-gw.eu/?content=3&r=21559       |
| 29 Mar | Quantum squeezing for Virgo and future generation gravitational-wave detectors   | Yuhang Zhao   |[International Conference on the Physics of the Two Infinities](https://indico.in2p3.fr/event/28466/) | https://indico.in2p3.fr/event/28466/sessions/18714/#20230329       |
| 22 Nov | Squeezed-vacuum techniques for quantum noise reduction in interferometric gravitational-wave detectors | Eleonora Capocasa   | [GdR Quantum technologies](https://gdrteqcolloq2023.sciencesconf.org)| https://drive.google.com/file/d/1OkuVwPUeEn6WKYiW7grYC0gGKp4IlrWm/view?usp=sharing   |


