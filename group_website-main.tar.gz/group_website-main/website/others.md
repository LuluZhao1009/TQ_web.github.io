# Students and Postdocs

## Jacques Ding

<div style="display: flex; align-items: center;">
    <img src="_static/ding.png" alt="Your Image" style="width: 40%; margin-right: 20px;">
    <p>
    <ul>
            <li>Position: PhD Student</li>
            <li>Research Area: Quantum Noise Reduction</li>
            <li>Bio: J.D is currently a PhD at APC from November 2022. He is also an Engineer of “Corps des Mines”. Before he obtained a master in quantum technologies & fundamental physics at École polytechnique. He was classed first out of 556 students in the final ranking, thus receiving the “Pierre-Simon Laplace Medal” from Académie des Sciences. He also obtained the “Grand Prize for Best Research Internship”, de l’École polytechnique, awarded for outstanding results obtained during the research internship in the Virgo Collaboration. He is visiting the MIT LIGO lab from October 2023 to October 2024.</li>
    </ul>
    </p>
</div>


## Yuhang Zhao

<div style="display: flex; align-items: center;">
    <img src="_static/zhao.png" alt="Your Image" style="width: 40%; margin-right: 20px;">
    <p>
    <ul>
            <li>Position: Postdoctoral Researcher</li>
            <li>Research Area: Quantum Noise Reduction</li>
            <li>Bio: Y.Z. is a postdoc at AstroParticle and Cosmology (APC) laboratory since December 2022. He obtained his master degree at the Beijing Normal University (China) and then he did a PhD at the National Astronomical Observatory of Japan. His thesis, about quantum noise reduction for gravitational-wave (GW) detectors, defended in 2020, was awarded the SOKENDAI prize for the most outstanding PhD thesis. Then he obtained a postdoctoral Fellowship at the Institute of Cosmic Ray Research (ICRR) during which he continued to contribute to the research on quantum noise reduction and on the development of the GW detector KAGRA. He was appointed sub-chief of the KAGRA quantum noise reduction group. He is the author of 50 publications.</li>
    </ul>
    </p>
</div>



## Léon Vidal

<div style="display: flex; align-items: center;">
    <img src="_static/leon.png" alt="Your Image" style="width: 40%; margin-right: 20px;">
    <p>
    <ul>
            <li>Position: Postdoctoral Researcher</li>
            <li>Research Area: Lunar GW detecors</li>
            <li>Bio: After obtaining his Master's degree at Observatoire de Paris, he briefly worked on improving ArianeGroup rockets before starting a PhD at the APC laboratory. His thesis, focusing on the experimental validation of interferometric performance for the LISA space mission, was defended in 2023. After securing funding from the Labex UnivEarths, he is investigating the feasibility of a lunar gravitational wave detector based on methods used in Virgo and LISA. He is also part of the Einstein Telescope collaboration.</li>
    </ul>
    </p>
</div>
